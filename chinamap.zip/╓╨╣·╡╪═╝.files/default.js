function Navgator(){
	var ns4 = (document.layers)?true:false;
	if(ns4){
		document.open();
		document.write("����ʹ��IE4���ϰ汾������������򽫲��������������վ��");
		document.close();
	}
}
Navgator();
function Links(DirName,Nav,id,type){
	var Number = Links.arguments.length
	var Linkstr
	var CodeStr
	var OpenUrl
	if(Nav=="none")return

	if(DirName != "")
		DirName = "/"+DirName+"/";
	switch(Number){
		case 2:
			Linkstr = "nav="+Nav
			break;
		case 3:
			Linkstr = "nav="+Nav+"&id="+id
			break;
		case 4:
			Linkstr = "nav="+Nav+"&id="+id+"&type="+type
			break;
		default:
			Linkstr = "none"
		}
	if(Linkstr!="none"){
		CodeStr = escape(Linkstr)
		OpenUrl = DirName+"?"+CodeStr
		}
	else OpenUrl = DirName
	if(type=="news"){
		newwin=window.open("/news/index.htm?"+CodeStr,'','width=780,height=500, scrollbars=yes, menubar=yes, top=0, left=0');
	}else if(DirName == "")
		newwin=window.open(OpenUrl,"_self")
	else{
		Navs = Nav.split('|');
		newwin=window.open(OpenUrl,Navs[0]);
		newwin.window.focus();
		if(window.name && window.name != Navs[0])window.close();
	}
}
function ShowNation(select){
	//alert(select.options[select.selectedIndex].value);
	//if(select.options[select.selectedIndex].value!='$') {
	if(select.options[select.selectedIndex].value!='none'){//select.selectedIndex != 0){
		URLName=select.options[select.selectedIndex].value
		Links("countries",URLName)
		}
	}

function LoadNation(zhouName){
	var zhouIndex = document.forms["world"].elements["selectzhou"].selectedIndex
	var NationName=nation[zhouIndex].split(',')
	var NationNameID=nationID[zhouIndex].split(',')
	document.forms["world"].elements["selectnation"].length = 1
	for (var i = 0; i < NationName.length ; i++){
		document.forms["world"].elements["selectnation"].options[i + 1] = new Option(NationName[i],NationNameID[i]);
		}
	}

function ShowText(PageId){
	//if(ShowText.arguments.length==0)PageId=1
	PageInfo = "<div align=center class=pageinfo>���Ĺ�"+(TextStr.length-1)+"ҳ����ǰΪ��"+PageId+"ҳ</div>";
	UpPageId = PageId-1
	DownPageId = PageId+1
	if(UpPageId>0)
		UpPage = "<a href=javascript:ShowText("+UpPageId+")>��һҳ</a>"
	else UpPage="��һҳ"
	if(DownPageId < TextStr.length) DownPage = "<a href=javascript:ShowText("+DownPageId+")>��һҳ</a>"
	else DownPage="��һҳ";
	var PageNumber = "";
	for(var index=0; index<TextStr.length-1; index++){
		var Number = index+1;
		PageNumber = PageNumber + "<a href=javascript:ShowText("+Number+")>"+Number+"</a>&nbsp;"
		if (Number==15 || Number==30 || Number==45)
		{PageNumber = PageNumber + "<br>"};
	}
	if(TextStr.length>2)
		ShowStr = TextStr[0]+PageInfo+TextStr[PageId]+"<p class=pages>" + UpPage+"&nbsp;&nbsp;"+PageNumber+"&nbsp;&nbsp;" + DownPage
	else ShowStr = TextStr[0]+TextStr[PageId];
	document.all["body"].innerHTML=ShowStr;
	window.scroll(0,0);
}

function ImgOpen(ImgPath,ImgName,Width,Height){
	
	var Number = ImgOpen.arguments.length
	if (Number==2)
	{
	window.open(ImgPath+"/images/"+ImgName)
	}
	else if(Number==4){
		window.open(ImgPath+"/images/"+ImgName,"","width="+Width+" height="+Height+" top=0 left=0 resizable=yes")
	}
}

function myImgOpen(path,name,size1,size2,info){
	//if(size1>700 || size2>550){
		window.open("/common/imgopencon.php?picinfo="+info+"&imgpath="+path+"&picname="+name,"img","scrollbars=yes resizable=yes width=650 height=550");
	//}else{
		//window.open("/common/imgopencon.php?picinfo="+info+"&imgpath="+path+"&picname="+name,"img","width="+size1+" height="+size2);
	//}
}

function PageOpen(PagePath,PageName,Width,Height){
	var Number = PageOpen.arguments.length
	if (Number==2)
	{
	window.open(PagePath+PageName)
	}
	else if(Number==4){
		window.open(PagePath+PageName,"","width="+Width+" height="+Height+" resizable=yes scrollbars=yes top=0 left=0")
		}
}

function ViewComment(Nav,Id,Type){
	if(Type == "commend"){
		document.cookie = "CommendUrl="+document.URL+";path=/";
	}
	var Str = "nav="+Nav+"&id="+Id+"&type="+Type;
	var NavStr = escape(Str);
	var UrlName = "/view.php3?"+NavStr;
	window.open(UrlName,Type);
}

function ValidateComment(){
	if(document.forms["addComment"].username.value == ""){
		window.alert("����д�û���");
		return false;
	}
	if(document.forms["addComment"].userpwd.value == ""){
		window.alert("����������");
		return false;
	}
	if(document.forms["addComment"].msgtitle.value == ""){
		window.alert("����д����");
		return false;
	}
	return true;
}

function userEmail(EmailStr){
	//var emailadd = document.FormName.EmailName.value;
	var pattern = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(\.[a-zA-Z0-9_-])+/;
	flag = pattern.test(EmailStr);
	if(flag) return true;
	else{
		alert("����E-mail��ַ�д��󣡣�");
		return false;
	}
}
function LoginMail(){
	//document.forms["ComposeForm"].action = "http://61.135.142.25/cgi-bin/login";
	//window.open("","mailwin","");
	//document.forms["ComposeForm"].submit();
	document.forms["ComposeForm"].password.value=document.forms["ComposeForm"].pwd.value;
	document.forms["ComposeForm"].pwd.value="";
}

function mOvr(src,clrOver) { if (!src.contains(event.fromElement)) { src.style.cursor = 'hand'; src.bgColor = clrOver; }}
function mOut(src,clrIn) { if (!src.contains(event.toElement)) { src.style.cursor = 'default'; src.bgColor = clrIn; }}
function mClk(src) { if(event.srcElement.tagName=='TD'){src.children.tags('A')[0].click();} }

//�й�������վ������
function ok(select){
	if(select.options[select.selectedIndex].value!='$') {
 		window.open(select.options[select.selectedIndex].value,'_blank');
	}
}

//��ҳ�ٿƺ��Ų�����ʾЧ��
function over(){
	if(obj=event.srcElement)
		if(obj.className=="flyoutLink"){
			obj.style.backgroundColor='E2AF68'
			obj.style.borderColor = '#999999'
		}
}
function out(){
	if(obj=event.srcElement)
		if(obj.className=="flyoutLink"){
			obj.style.backgroundColor='FFEFBD'
			obj.style.borderColor = ''
		}
}
function show(d){
	
	if(obj=document.all(d))	{
			obj.style.display=""
			
	}
}
function hide(d){
	if(obj=document.all(d))	obj.style.display="none"
}

document.onmouseover=over
document.onmouseout=out


function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);


//---------------------------------------------------------

function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}
MM_reloadPage(true);
// -->

function MM_timelinePlay(tmLnName, myID) { //v1.2
  //Copyright 1997 Macromedia, Inc. All rights reserved.
  var i,j,tmLn,props,keyFrm,sprite,numKeyFr,firstKeyFr,propNum,theObj,firstTime=false;
  if (document.MM_Time == null) MM_initTimelines(); //if *very* 1st time
  tmLn = document.MM_Time[tmLnName];
  if (myID == null) { myID = ++tmLn.ID; firstTime=true;}//if new call, incr ID
  if (myID == tmLn.ID) { //if Im newest
    setTimeout('MM_timelinePlay("'+tmLnName+'",'+myID+')',tmLn.delay);
    fNew = ++tmLn.curFrame;
    for (i=0; i<tmLn.length; i++) {
      sprite = tmLn[i];
      if (sprite.charAt(0) == 's') {
        if (sprite.obj) {
          numKeyFr = sprite.keyFrames.length; firstKeyFr = sprite.keyFrames[0];
          if (fNew >= firstKeyFr && fNew <= sprite.keyFrames[numKeyFr-1]) {//in range
            keyFrm=1;
            for (j=0; j<sprite.values.length; j++) {
              props = sprite.values[j]; 
              if (numKeyFr != props.length) {
                if (props.prop2 == null) sprite.obj[props.prop] = props[fNew-firstKeyFr];
                else        sprite.obj[props.prop2][props.prop] = props[fNew-firstKeyFr];
              } else {
                while (keyFrm<numKeyFr && fNew>=sprite.keyFrames[keyFrm]) keyFrm++;
                if (firstTime || fNew==sprite.keyFrames[keyFrm-1]) {
                  if (props.prop2 == null) sprite.obj[props.prop] = props[keyFrm-1];
                  else        sprite.obj[props.prop2][props.prop] = props[keyFrm-1];
        } } } } }
      } else if (sprite.charAt(0)=='b' && fNew == sprite.frame) eval(sprite.value);
      if (fNew > tmLn.lastFrame) tmLn.ID = 0;
  } }
}

function MM_timelineGoto(tmLnName, fNew, numGotos) { //v2.0
  //Copyright 1997 Macromedia, Inc. All rights reserved.
  var i,j,tmLn,props,keyFrm,sprite,numKeyFr,firstKeyFr,lastKeyFr,propNum,theObj;
  if (document.MM_Time == null) MM_initTimelines(); //if *very* 1st time
  tmLn = document.MM_Time[tmLnName];
  if (numGotos != null)
    if (tmLn.gotoCount == null) tmLn.gotoCount = 1;
    else if (tmLn.gotoCount++ >= numGotos) {tmLn.gotoCount=0; return}
  jmpFwd = (fNew > tmLn.curFrame);
  for (i = 0; i < tmLn.length; i++) {
    sprite = (jmpFwd)? tmLn[i] : tmLn[(tmLn.length-1)-i]; //count bkwds if jumping back
    if (sprite.charAt(0) == "s") {
      numKeyFr = sprite.keyFrames.length;
      firstKeyFr = sprite.keyFrames[0];
      lastKeyFr = sprite.keyFrames[numKeyFr - 1];
      if ((jmpFwd && fNew<firstKeyFr) || (!jmpFwd && lastKeyFr<fNew)) continue; //skip if untouchd
      for (keyFrm=1; keyFrm<numKeyFr && fNew>=sprite.keyFrames[keyFrm]; keyFrm++);
      for (j=0; j<sprite.values.length; j++) {
        props = sprite.values[j];
        if (numKeyFr == props.length) propNum = keyFrm-1 //keyframes only
        else propNum = Math.min(Math.max(0,fNew-firstKeyFr),props.length-1); //or keep in legal range
        if (sprite.obj != null) {
          if (props.prop2 == null) sprite.obj[props.prop] = props[propNum];
          else        sprite.obj[props.prop2][props.prop] = props[propNum];
      } }
    } else if (sprite.charAt(0)=='b' && fNew == sprite.frame) eval(sprite.value);
  }
  tmLn.curFrame = fNew;
  if (tmLn.ID == 0) eval('MM_timelinePlay(tmLnName)');
}

function MM_initTimelines() { //v4.0
    //MM_initTimelines() Copyright 1997 Macromedia, Inc. All rights reserved.
    var ns = navigator.appName == "Netscape";
    var ns4 = (ns && parseInt(navigator.appVersion) == 4);
    var ns5 = (ns && parseInt(navigator.appVersion) > 4);
    document.MM_Time = new Array(1);
    document.MM_Time[0] = new Array(2);
    document.MM_Time["Timeline1"] = document.MM_Time[0];
    document.MM_Time[0].MM_Name = "Timeline1";
    document.MM_Time[0].fps = 5;
    document.MM_Time[0][0] = new String("sprite");
    document.MM_Time[0][0].slot = 1;
    if (ns4)
        document.MM_Time[0][0].obj = document["Layer2"];
    else if (ns5)
        document.MM_Time[0][0].obj = document.getElementById("Layer2");
    else
        document.MM_Time[0][0].obj = document.all ? document.all["Layer2"] : null;
    document.MM_Time[0][0].keyFrames = new Array(1, 30, 60, 90, 120);
    document.MM_Time[0][0].values = new Array(2);
    if (ns5)
        document.MM_Time[0][0].values[0] = new Array("124px", "148px", "171px", "195px", "218px", "242px", "266px", "289px", "313px", "337px", "360px", "384px", "408px", "431px", "455px", "478px", "502px", "526px", "549px", "573px", "597px", "620px", "644px", "667px", "691px", "714px", "738px", "761px", "784px", "803px", "783px", "760px", "736px", "713px", "690px", "666px", "643px", "619px", "596px", "573px", "549px", "525px", "502px", "478px", "455px", "431px", "408px", "384px", "361px", "337px", "314px", "290px", "267px", "243px", "220px", "197px", "173px", "150px", "127px", "107px", "126px", "149px", "171px", "194px", "217px", "240px", "264px", "287px", "310px", "333px", "356px", "379px", "402px", "425px", "448px", "471px", "494px", "517px", "540px", "563px", "585px", "608px", "631px", "653px", "676px", "698px", "720px", "742px", "764px", "782px", "766px", "745px", "724px", "702px", "681px", "659px", "638px", "616px", "595px", "573px", "552px", "530px", "509px", "488px", "466px", "445px", "424px", "402px", "381px", "360px", "339px", "317px", "296px", "275px", "253px", "232px", "211px", "189px", "168px", "147px");
    else
        document.MM_Time[0][0].values[0] = new Array(124,148,171,195,218,242,266,289,313,337,360,384,408,431,455,478,502,526,549,573,597,620,644,667,691,714,738,761,784,803,783,760,736,713,690,666,643,619,596,573,549,525,502,478,455,431,408,384,361,337,314,290,267,243,220,197,173,150,127,107,126,149,171,194,217,240,264,287,310,333,356,379,402,425,448,471,494,517,540,563,585,608,631,653,676,698,720,742,764,782,766,745,724,702,681,659,638,616,595,573,552,530,509,488,466,445,424,402,381,360,339,317,296,275,253,232,211,189,168,147);
    document.MM_Time[0][0].values[0].prop = "left";
    if (ns5)
        document.MM_Time[0][0].values[1] = new Array("127px", "131px", "135px", "139px", "143px", "146px", "150px", "154px", "157px", "161px", "165px", "168px", "172px", "176px", "179px", "183px", "187px", "191px", "195px", "199px", "203px", "208px", "212px", "217px", "221px", "227px", "232px", "238px", "246px", "259px", "269px", "274px", "277px", "280px", "282px", "284px", "286px", "288px", "290px", "292px", "293px", "295px", "297px", "298px", "300px", "301px", "303px", "304px", "306px", "308px", "309px", "311px", "313px", "315px", "317px", "320px", "323px", "326px", "331px", "341px", "353px", "359px", "365px", "369px", "374px", "378px", "381px", "385px", "389px", "392px", "396px", "399px", "403px", "406px", "409px", "413px", "416px", "420px", "423px", "427px", "430px", "434px", "438px", "442px", "446px", "450px", "455px", "460px", "467px", "479px", "493px", "500px", "505px", "510px", "515px", "519px", "522px", "526px", "529px", "532px", "535px", "538px", "541px", "544px", "547px", "550px", "552px", "555px", "558px", "560px", "563px", "565px", "568px", "570px", "573px", "576px", "578px", "581px", "584px", "587px");
    else
        document.MM_Time[0][0].values[1] = new Array(127,131,135,139,143,146,150,154,157,161,165,168,172,176,179,183,187,191,195,199,203,208,212,217,221,227,232,238,246,259,269,274,277,280,282,284,286,288,290,292,293,295,297,298,300,301,303,304,306,308,309,311,313,315,317,320,323,326,331,341,353,359,365,369,374,378,381,385,389,392,396,399,403,406,409,413,416,420,423,427,430,434,438,442,446,450,455,460,467,479,493,500,505,510,515,519,522,526,529,532,535,538,541,544,547,550,552,555,558,560,563,565,568,570,573,576,578,581,584,587);
    document.MM_Time[0][0].values[1].prop = "top";
    if (!ns4) {
        document.MM_Time[0][0].values[0].prop2 = "style";
        document.MM_Time[0][0].values[1].prop2 = "style";
    }
    document.MM_Time[0][1] = new String("behavior");
    document.MM_Time[0][1].frame = 120;
    document.MM_Time[0][1].value = "MM_timelineGoto('Timeline1','1')";
    document.MM_Time[0].lastFrame = 120;
    for (i=0; i<document.MM_Time.length; i++) {
        document.MM_Time[i].ID = null;
        document.MM_Time[i].curFrame = 0;
        document.MM_Time[i].delay = 1000/document.MM_Time[i].fps;
    }
}
